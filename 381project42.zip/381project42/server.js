const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

// 模拟的用户数据库 (明文密码)
const users = [
  { id: 1, username: 'Mike', password: '1234' }
];

// 模拟的管理员数据库 (明文密码)
const admins = [
  { id: 1, username: 'admin', password: '1234' }
];

// 设置视图引擎为 EJS
app.set('view engine', 'ejs');

// 中间件，用于解析请求体数据
app.use(bodyParser.urlencoded({ extended: true }));

// 设置静态文件目录
app.use(express.static('public'));

// 配置 session
app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}));

// 登录页路由
app.get('/login', (req, res) => {
  res.render('login');
});

// 处理登录请求
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  // 查找管理员
  const admin = admins.find(u => u.username === username && u.password === password);
  
  if (admin) {
    // 如果匹配管理员，设置 session 并跳转到管理员主页
    req.session.adminId = admin.id;
    return res.redirect('/adminHome');
  }

  // 查找普通用户
  const user = users.find(u => u.username === username && u.password === password);
  
  if (user) {
    // 如果匹配用户，设置 session 并跳转到用户主页
    req.session.userId = user.id;
    return res.redirect('/home');
  }

  // 如果都不匹配，返回错误信息
  res.send('Invalid username or password');
});

// 普通用户主页
app.get('/home', (req, res) => {
  if (!req.session.userId) {
    return res.redirect('/login');
  }
  res.render('home');
});

// 管理员主页
app.get('/adminHome', (req, res) => {
  if (!req.session.adminId) {
    return res.redirect('/login');
  }
  res.render('adminHome');
});

// CRUD 页面，仅已登录的用户可访问
app.get('/crud', (req, res) => {
  if (!req.session.userId) {
    return res.redirect('/login');
  }
  
  res.render('crud');
});

// 处理登出请求
app.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.redirect('/home');
    }
    res.redirect('/login');
  });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}/login`);
});
